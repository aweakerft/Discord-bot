# VietHoa Bot - Discord Bot for Translating Minecraft Files to Vietnamese

VietHoa Bot is a Discord bot designed to translate Minecraft plugin configuration files, language files, and other code files to Vietnamese while preserving the code structure. The bot uses AI models like Gemini or GPT to intelligently identify what should be translated and what should remain unchanged.

## Features

- Translates Minecraft plugin configuration files to Vietnamese
- Preserves code structure and functionality
- Supports multiple file formats (.yml, .json, .properties, .lang, .sk, etc.)
- Uses advanced AI models (Gemini 2.0 Flash or GPT-4)
- Supports multiple API keys for parallel translation
- User management system with whitelist and blacklist
- Simple Discord commands
- Works in both server channels and direct messages

## Commands

### User Commands
- `!viethoa` - Translate an attached file to Vietnamese
- `/ping` - Check the bot's response latency
- `/cai` - Show the current AI model being used
- `/test` - Test translate a short text

### Admin Commands (Bot Owner Only)
- `/wl` - Add a user to the whitelist
- `/bl` - Add a user to the blacklist
- `/rwl` - Remove a user from the whitelist
- `/rbl` - Remove a user from the blacklist
- `/mkey` - Set the maximum number of API keys a user can use
- `/rmkey` - Reduce the number of API keys a user can use

## Setup

1. Clone this repository
2. Install dependencies with `npm install`
3. Create a `.env` file based on `.env.example` and fill in your Discord token, AI API keys, and bot owner ID
4. Start the bot with `npm start`

## Environment Variables

Create a `.env` file with the following variables:

```
# Discord Bot Token
DISCORD_TOKEN=your_discord_bot_token_here

# AI API Keys (can add multiple Gemini keys)
OPENAI_API_KEY=your_openai_api_key_here
GEMINI_API_KEY=your_gemini_api_key_here
GEMINI_API_KEY_1=your_second_gemini_api_key_here
GEMINI_API_KEY_2=your_third_gemini_api_key_here
# Add more Gemini API keys as needed (up to GEMINI_API_KEY_9)

# Default AI Model (openai or gemini)
DEFAULT_AI_MODEL=gemini

# Bot Owner ID (for admin commands)
BOT_OWNER_ID=your_discord_user_id_here
```

## Supported File Formats

- YAML (.yml, .yaml)
- JSON (.json)
- Properties (.properties, .lang)
- Configuration files (.cfg, .conf, .config, .ini)
- Skript files (.sk)
- Text files (.txt)
- And more

## User Management

The bot includes a user management system with the following features:

- **Whitelist**: Only users on the whitelist can use the bot (if whitelist is not empty)
- **Blacklist**: Users on the blacklist cannot use the bot
- **API Key Management**: Control how many API keys each user can use for parallel translation
- **Duration Control**: Set how long users remain on whitelist or blacklist (minutes, days, months, years, or forever)

## How It Works

1. User sends a file with the `!viethoa` command
2. Bot checks if the user is allowed to use the bot (not blacklisted and on whitelist if required)
3. Bot downloads and processes the file
4. Bot determines how many API keys the user is allowed to use
5. Bot splits the file into chunks and sends them to the AI service(s) in parallel
6. AI translates the text while preserving code structure
7. Bot combines the translated chunks and verifies the integrity of the translation
8. Bot sends the translated file back to the user via DM
9. Bot cleans up temporary files

## Contributing

Contributions are welcome! Please feel free to submit a Pull Request.

## License

This project is licensed under the MIT License - see the LICENSE file for details.
import fs from 'fs-extra';
import yaml from 'js-yaml';
import path from 'path';
import { translateWithGemini } from './ai-service.js';
import chalk from 'chalk';

/**
 * Translates a file to Vietnamese
 * @param {string} filePath - Path to the file
 * @param {string} fileExtension - File extension
 * @param {string} userId - User ID for API key allocation
 * @param {function} progressCallback - Callback for progress updates
 * @returns {Promise<string>} - Translated content
 */
export async function translateFile(filePath, fileExtension, userId, progressCallback = null) {
  // Read file content
  const content = await fs.readFile(filePath, 'utf8');
  
  // Get file size for logging
  const stats = await fs.stat(filePath);
  const fileSizeKB = Math.round(stats.size / 1024);
  console.log(chalk.blue(`Processing file: ${path.basename(filePath)} (${fileSizeKB} KB)`));
  
  // Parse file based on extension
  let parsedContent;
  let translationPrompt;
  let outputFormat;
  
  switch (fileExtension) {
    case '.yml':
    case '.yaml':
      try {
        parsedContent = yaml.load(content);
        translationPrompt = createYamlTranslationPrompt(content, parsedContent);
        outputFormat = 'yaml';
      } catch (error) {
        console.error(chalk.red('Error parsing YAML:', error));
        translationPrompt = createGenericTranslationPrompt(content);
        outputFormat = 'text';
      }
      break;
    case '.json':
      try {
        parsedContent = JSON.parse(content);
        translationPrompt = createJsonTranslationPrompt(content, parsedContent);
        outputFormat = 'json';
      } catch (error) {
        console.error(chalk.red('Error parsing JSON:', error));
        translationPrompt = createGenericTranslationPrompt(content);
        outputFormat = 'text';
      }
      break;
    case '.properties':
    case '.lang':
      translationPrompt = createPropertiesTranslationPrompt(content);
      outputFormat = 'properties';
      break;
    case '.cfg':
    case '.conf':
    case '.config':
    case '.ini':
      translationPrompt = createConfigTranslationPrompt(content);
      outputFormat = 'config';
      break;
    case '.sk':
      translationPrompt = createSkriptTranslationPrompt(content);
      outputFormat = 'sk';
      break;
    default:
      translationPrompt = createGenericTranslationPrompt(content);
      outputFormat = 'text';
  }
  
  console.log(chalk.green(`Translation started with format: ${outputFormat}`));
  
  try {
    const translatedContent = await translateWithGemini(translationPrompt, outputFormat, userId, progressCallback);
    
    // Verify the translation based on file type
    let verifiedContent = translatedContent;
    
    if (fileExtension === '.yml' || fileExtension === '.yaml') {
      verifiedContent = await verifyYamlTranslation(content, translatedContent);
    } else if (fileExtension === '.json') {
      verifiedContent = await verifyJsonTranslation(content, translatedContent);
    } else if (fileExtension === '.properties' || fileExtension === '.lang') {
      verifiedContent = await verifyPropertiesTranslation(content, translatedContent);
    }
    
    // Final pass to ensure Minecraft formatting is preserved
    verifiedContent = preserveMinecraftFormatting(content, verifiedContent);
    
    return verifiedContent;
  } catch (error) {
    console.error(chalk.red('Translation failed:', error));
    throw error;
  }
}

/**
 * Creates a translation prompt for YAML files
 * @param {string} rawContent - Raw file content
 * @param {object} parsedContent - Parsed YAML content
 * @returns {string} - Translation prompt
 */
function createYamlTranslationPrompt(rawContent, parsedContent) {
  return `
You are an expert in translating Minecraft plugins from English to Vietnamese.

Here is a YAML configuration file from a Minecraft plugin:

\`\`\`yaml
${rawContent}
\`\`\`

Translation rules:
1. Translate all user-facing text to Vietnamese
2. DO NOT translate:
   - YAML keys (before the colon :)
   - Technical values like command names, permissions, plugin names
   - Placeholders like %player%, {player}, <player>, {land}, {nation}, {level}, {current}, {object}, {cmd_create}, {cmd_edit}
   - Color codes like &a, &b, &c, §a, §b, §c, &1-&9, §1-§9
   - Special tags like [T], [H], [C], [SC], [/T], [/H], [/C], [/SC], [CLICK]
   - Variables, technical parameters
3. Preserve exact structure and formatting
4. Maintain line count and indentation
5. Keep special characters intact
6. For text within single quotes ('...'), translate ONLY the human-readable text:
   Example:
   '&cYou can''t create a nation with a camp &8(&4{land}&8) &cas the capital.'
   Should become:
   '&cBạn không thể tạo quốc gia với trại &8(&4{land}&8) &clàm thủ đô.'

Return ONLY the translated YAML content without any formatting or explanation.
`;
}

/**
 * Creates a translation prompt for JSON files
 * @param {string} rawContent - Raw file content
 * @param {object} parsedContent - Parsed JSON content
 * @returns {string} - Translation prompt
 */
function createJsonTranslationPrompt(rawContent, parsedContent) {
  return `
You are an expert in translating Minecraft plugins from English to Vietnamese.

Here is a JSON file from a Minecraft plugin:

\`\`\`json
${rawContent}
\`\`\`

Translation rules:
1. Translate all user-facing text to Vietnamese
2. DO NOT translate:
   - JSON keys
   - Technical values like command names, permissions, plugin names
   - Placeholders like %player%, {player}, <player>, {land}, {nation}, {level}, {current}
   - Color codes like &a, &b, &c, §a, §b, §c, &1-&9, §1-§9
   - Special tags like [T], [H], [C], [SC], [/T], [/H], [/C], [/SC], [CLICK]
   - Variables, technical parameters
3. Preserve exact structure and formatting
4. Maintain line count and indentation
5. Keep special characters intact
6. For text within quotes, translate ONLY the human-readable text while preserving formatting

Return ONLY the translated JSON content without any formatting or explanation.
`;
}

/**
 * Creates a translation prompt for properties files
 * @param {string} content - File content
 * @returns {string} - Translation prompt
 */
function createPropertiesTranslationPrompt(content) {
  return `
You are an expert in translating Minecraft plugins from English to Vietnamese.

Here is a properties/lang file from a Minecraft plugin:

\`\`\`properties
${content}
\`\`\`

Translation rules:
1. Translate all user-facing text to Vietnamese
2. DO NOT translate:
   - Keys on the left side of the = sign
   - Technical values like command names, permissions, plugin names
   - Placeholders like %player%, {player}, <player>, {land}, {nation}, {level}, {current}
   - Color codes like &a, &b, &c, §a, §b, §c, &1-&9, §1-§9
   - Special tags like [T], [H], [C], [SC], [/T], [/H], [/C], [/SC], [CLICK]
   - Variables, technical parameters
3. Preserve exact structure and formatting
4. Maintain line count
5. Keep special characters intact
6. For text within quotes, translate ONLY the human-readable text while preserving formatting

Return ONLY the translated properties content without any formatting or explanation.
`;
}

/**
 * Creates a translation prompt for config files
 * @param {string} content - File content
 * @returns {string} - Translation prompt
 */
function createConfigTranslationPrompt(content) {
  return `
You are an expert in translating Minecraft plugins from English to Vietnamese.

Here is a configuration file from a Minecraft plugin:

\`\`\`config
${content}
\`\`\`

Translation rules:
1. Translate all user-facing text to Vietnamese
2. DO NOT translate:
   - Configuration keys
   - Technical values like command names, permissions, plugin names
   - Placeholders like %player%, {player}, <player>, {land}, {nation}, {level}, {current}
   - Color codes like &a, &b, &c, §a, §b, §c, &1-&9, §1-§9
   - Special tags like [T], [H], [C], [SC], [/T], [/H], [/C], [/SC], [CLICK]
   - Variables, technical parameters
3. Preserve exact structure and formatting
4. Maintain line count and indentation
5. Keep special characters intact
6. For text within quotes, translate ONLY the human-readable text while preserving formatting

Return ONLY the translated configuration content without any formatting or explanation.
`;
}

/**
 * Creates a translation prompt for Skript files
 * @param {string} content - File content
 * @returns {string} - Translation prompt
 */
function createSkriptTranslationPrompt(content) {
  return `
You are an expert in translating Minecraft plugins from English to Vietnamese.

Here is a Skript file from a Minecraft plugin:

\`\`\`sk
${content}
\`\`\`

Translation rules:
1. Translate all user-facing text to Vietnamese
2. DO NOT translate:
   - Skript syntax and commands
   - Variable names and function names
   - Technical values like command names, permissions, plugin names
   - Placeholders like %player%, {player}, <player>, {land}, {nation}, {level}, {current}
   - Color codes like &a, &b, &c, §a, §b, §c, &1-&9, §1-§9
   - Special tags like [T], [H], [C], [SC], [/T], [/H], [/C], [/SC], [CLICK]
   - Variables, technical parameters
3. Preserve exact structure and formatting
4. Maintain line count and indentation
5. Keep special characters intact
6. For text within quotes, translate ONLY the human-readable text while preserving formatting

Return ONLY the translated Skript content without any formatting or explanation.
`;
}

/**
 * Creates a translation prompt for generic text files
 * @param {string} content - File content
 * @returns {string} - Translation prompt
 */
function createGenericTranslationPrompt(content) {
  return `
You are an expert in translating Minecraft plugins from English to Vietnamese.

Here is a text file from a Minecraft plugin:

\`\`\`text
${content}
\`\`\`

Translation rules:
1. Translate all user-facing text to Vietnamese
2. DO NOT translate:
   - Technical values like command names, permissions, plugin names
   - Placeholders like %player%, {player}, <player>, {land}, {nation}, {level}, {current}
   - Color codes like &a, &b, &c, §a, §b, §c, &1-&9, §1-§9
   - Special tags like [T], [H], [C], [SC], [/T], [/H], [/C], [/SC], [CLICK]
   - Variables, technical parameters
3. Preserve exact structure and formatting
4. Maintain line count
5. Keep special characters intact
6. For text within quotes, translate ONLY the human-readable text while preserving formatting

Return ONLY the translated text content without any formatting or explanation.
`;
}

/**
 * Preserves Minecraft formatting in translated text
 * @param {string} original - Original content
 * @param {string} translated - Translated content
 * @returns {string} - Content with preserved formatting
 */
function preserveMinecraftFormatting(original, translated) {
  const originalLines = original.split('\n');
  const translatedLines = translated.split('\n');
  const fixedLines = [];

  for (let i = 0; i < originalLines.length; i++) {
    const originalLine = originalLines[i];
    let translatedLine = translatedLines[i] || originalLine;

    // Handle quoted text with color codes and placeholders
    const quotedTextRegex = /'([^']+)'/g;
    const originalQuotes = originalLine.match(quotedTextRegex);
    const translatedQuotes = translatedLine.match(quotedTextRegex);

    if (originalQuotes && translatedQuotes) {
      for (let j = 0; j < originalQuotes.length; j++) {
        const originalQuote = originalQuotes[j];
        const translatedQuote = translatedQuotes[j] || originalQuote;

        // Preserve color codes
        const colorCodes = originalQuote.match(/&[0-9a-fklmnor]/g) || [];
        let fixedQuote = translatedQuote;
        colorCodes.forEach((code, index) => {
          if (!translatedQuote.includes(code)) {
            const position = originalQuote.indexOf(code);
            const relativePosition = position / originalQuote.length;
            const insertPosition = Math.floor(translatedQuote.length * relativePosition);
            fixedQuote = fixedQuote.slice(0, insertPosition) + code + fixedQuote.slice(insertPosition);
          }
        });

        // Preserve placeholders
        const placeholders = originalQuote.match(/\{[^}]+\}/g) || [];
        placeholders.forEach(placeholder => {
          if (!fixedQuote.includes(placeholder)) {
            fixedQuote = fixedQuote.replace(/\{[^}]+\}/, placeholder);
          }
        });

        // Preserve special tags
        const specialTags = originalQuote.match(/\[[^\]]+\]/g) || [];
        specialTags.forEach(tag => {
          if (!fixedQuote.includes(tag)) {
            fixedQuote = fixedQuote.replace(/\[[^\]]+\]/, tag);
          }
        });

        translatedLine = translatedLine.replace(translatedQuote, fixedQuote);
      }
    }

    // Handle YAML keys
    const keyMatch = originalLine.match(/^(\s*)([\w\-\.]+)(:)(.*)$/);
    if (keyMatch) {
      const [_, indent, key, colon, rest] = keyMatch;
      const translatedRest = translatedLine.replace(/^[\s\w\-\.]+:/, '').trim();
      translatedLine = `${indent}${key}:${rest.length > 0 ? ' ' + translatedRest : ''}`;
    }

    fixedLines.push(translatedLine);
  }

  return fixedLines.join('\n');
}

/**
 * Verifies and fixes YAML translation
 * @param {string} original - Original content
 * @param {string} translated - Translated content
 * @returns {Promise<string>} - Verified content
 */
async function verifyYamlTranslation(original, translated) {
  try {
    // Try to parse the translated YAML
    yaml.load(translated);
    return translated;
  } catch (error) {
    console.warn(chalk.yellow('YAML validation failed, attempting to fix...'));
    
    const originalLines = original.split('\n');
    const translatedLines = translated.split('\n');
    const fixedLines = [];
    
    for (let i = 0; i < originalLines.length; i++) {
      const originalLine = originalLines[i];
      let translatedLine = translatedLines[i] || originalLine;
      
      // Fix YAML keys
      const keyMatch = originalLine.match(/^(\s*)([\w\-\.]+)(:)(.*)$/);
      if (keyMatch) {
        const [_, indent, key, colon, rest] = keyMatch;
        const translatedRest = translatedLine.replace(/^[\s\w\-\.]+:/, '').trim();
        translatedLine = `${indent}${key}:${rest.length > 0 ? ' ' + translatedRest : ''}`;
      }
      
      // Fix list items
      const listMatch = originalLine.match(/^(\s*)-\s/);
      if (listMatch) {
        const indent = listMatch[1];
        const content = translatedLine.replace(/^\s*-\s/, '').trim();
        translatedLine = `${indent}- ${content}`;
      }
      
      fixedLines.push(translatedLine);
    }
    
    return fixedLines.join('\n');
  }
}

/**
 * Verifies and fixes JSON translation
 * @param {string} original - Original content
 * @param {string} translated - Translated content
 * @returns {Promise<string>} - Verified content
 */
async function verifyJsonTranslation(original, translated) {
  try {
    // Try to parse the translated JSON
    JSON.parse(translated);
    return translated;
  } catch (error) {
    console.warn(chalk.yellow('JSON validation failed, attempting to fix...'));
    
    const originalLines = original.split('\n');
    const translatedLines = translated.split('\n');
    const fixedLines = [];
    
    for (let i = 0; i < originalLines.length; i++) {
      const originalLine = originalLines[i];
      let translatedLine = translatedLines[i] || originalLine;
      
      // Fix JSON keys
      const keyMatch = originalLine.match(/^(\s*)"([\w\-\.]+)":\s/);
      if (keyMatch) {
        const [_, indent, key] = keyMatch;
        const value = translatedLine.replace(/^\s*"[\w\-\.]+"\s*:\s*/, '').trim();
        translatedLine = `${indent}"${key}": ${value}`;
      }
      
      fixedLines.push(translatedLine);
    }
    
    return fixedLines.join('\n');
  }
}

/**
 * Verifies and fixes properties translation
 * @param {string} original - Original content
 * @param {string} translated - Translated content
 * @returns {Promise<string>} - Verified content
 */
async function verifyPropertiesTranslation(original, translated) {
  const originalLines = original.split('\n');
  const translatedLines = translated.split('\n');
  const fixedLines = [];
  
  for (let i = 0; i < originalLines.length; i++) {
    const originalLine = originalLines[i];
    let translatedLine = translatedLines[i] || originalLine;
    
    // Fix property keys
    const keyMatch = originalLine.match(/^([\w\-\.]+)\s*=\s*/);
    if (keyMatch) {
      const key = keyMatch[1];
      const value = translatedLine.replace(/^[\w\-\.]+\s*=\s*/, '').trim();
      translatedLine = `${key}=${value}`;
    }
    
    fixedLines.push(translatedLine);
  }
  
  return fixedLines.join('\n');
}